(function() {

    // Paul Conigliaro
    function getPathLength(shapePath) {
        var len = 0;
        var verts = shapePath.vertices;
        var numVerts = verts.length;
        var ins = shapePath.inTangents;
        var outs = shapePath.outTangents;

        for (var i = 0; i < numVerts - 1; i++) {
            len += getCurveLength(verts[i],verts[i+1],outs[i],ins[i+1]);
        }

        if (shapePath.closed == true) {
            len += getCurveLength(verts[numVerts-1],verts[0],outs[numVerts-1],ins[0]);
        }

        return len;
    }

    // Hernan Torrisi
    function getCurveLength(initPos, endPos, outBezier, inBezier) {
        var k, curveSegments = 100, point, lastPoint = null, ptDistance, absToCoord, absTiCoord, triCoord1, triCoord2, triCoord3, liCoord1, liCoord2, ptCoord, perc, addedLength = 0, i, len;
        for (k = 0; k < curveSegments; k += 1) {
            point = [];
            perc = k / (curveSegments - 1);
            ptDistance = 0;
            absToCoord = [];
            absTiCoord = [];
            len = outBezier.length;
            for (i = 0; i < len; i += 1) {
                if (absToCoord[i] === null || absToCoord[i] === undefined) {
                    absToCoord[i] = initPos[i] + outBezier[i];
                    absTiCoord[i] = endPos[i] + inBezier[i];
                }
                triCoord1 = initPos[i] + (absToCoord[i] - initPos[i]) * perc;
                triCoord2 = absToCoord[i] + (absTiCoord[i] - absToCoord[i]) * perc;
                triCoord3 = absTiCoord[i] + (endPos[i] - absTiCoord[i]) * perc;
                liCoord1 = triCoord1 + (triCoord2 - triCoord1) * perc;
                liCoord2 = triCoord2 + (triCoord3 - triCoord2) * perc;
                ptCoord = liCoord1 + (liCoord2 - liCoord1) * perc;
                point.push(ptCoord);
                if (lastPoint !== null) {
                    ptDistance += Math.pow(point[i] - lastPoint[i], 2);
                }
            }
            ptDistance = Math.sqrt(ptDistance);
            addedLength += ptDistance;
            lastPoint = point;
        }
        return addedLength;
    }


    try {
        var altKey = ScriptUI.environment.keyboardState.altKey;

        app.beginUndoGroup("Create RubberHose Rig");

        var comp = app.project.activeItem;

        var hoseLayer = comp.selectedLayers[0];
        var shapeLayer = comp.selectedLayers[1];
        var startLayer = comp.layer( hoseLayer(2)("Admin")(2)("B")(2)(1).name );
        var endLayer = comp.layer( hoseLayer(2)("Admin")(2)("A")(2)(1).name );

        var strokePath = shapeLayer.property("ADBE Root Vectors Group").property("ADBE Vector Group").property("ADBE Vectors Group").property("ADBE Vector Shape - Group").property("ADBE Vector Shape").value;
        var strokeColor = shapeLayer.property("ADBE Root Vectors Group").property("ADBE Vector Group").property("ADBE Vectors Group").property("ADBE Vector Graphic - Stroke").property("ADBE Vector Stroke Color").value;
        var strokeWidth = shapeLayer.property("ADBE Root Vectors Group").property("ADBE Vector Group").property("ADBE Vectors Group").property("ADBE Vector Graphic - Stroke").property("ADBE Vector Stroke Width").value;

        var strokeLength = Math.round(getPathLength(strokePath) * 100) / 100;
       
        var eff = endLayer(4)("RubberHose 2");
        eff("Hose Length").setValue(strokeLength);
        eff("Realism").setValue(100);
        // startLayer.property("ADBE Effect Parade").property(1).property(1).setValue(strokeLength);
        // startLayer.property("ADBE Effect Parade").property(1).property(3).setValue(100);

        var vertices = strokePath.vertices;
        var firstVert = vertices[0];
        var lastVert = vertices[vertices.length - 1];

        var anchorPoint = shapeLayer.transform.position.value;

        var startPosition = (altKey === true) ? anchorPoint + lastVert : anchorPoint + firstVert;
        var endPosition = (altKey === true) ? anchorPoint + firstVert : anchorPoint + lastVert;

        startLayer.transform.position.setValue(startPosition);
        endLayer.transform.position.setValue(endPosition);

        var hoseStroke = hoseLayer.property("ADBE Root Vectors Group").property("ADBE Vector Group").property("ADBE Vectors Group").property("ADBE Vector Group").property("ADBE Vectors Group").property("ADBE Vector Graphic - Stroke");

        hoseStroke.property("ADBE Vector Stroke Color").setValue(strokeColor);
        hoseStroke.property("ADBE Vector Stroke Width").setValue(strokeWidth);

    } catch(err) {
        alert(err);
    } finally {
        app.endUndoGroup();
    }

})();